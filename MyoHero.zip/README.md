# MyoHero
Guitar Hero with Kinect, Myo and Oculus
